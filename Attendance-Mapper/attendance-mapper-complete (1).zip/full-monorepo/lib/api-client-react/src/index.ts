import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

const BASE_URL = (import.meta as any).env?.VITE_API_URL ?? "/api";

async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { "Content-Type": "application/json", ...init?.headers },
    ...init,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "Unknown error");
    throw new Error(`API ${init?.method ?? "GET"} ${path} failed ${res.status}: ${text}`);
  }
  return res.json() as Promise<T>;
}

// ─── Types ────────────────────────────────────────────────────────────────────

export interface Department {
  id: number;
  name: string;
  code: string | null;
  displayOrder: number;
  createdAt: string;
  employeeCount: number;
}

export interface Employee {
  id: number;
  employeeCode: string;
  name: string;
  departmentId: number;
  departmentName: string;
  designation: string | null;
  monthlyWage: number;
  statsEligible: boolean;
  otEligible: boolean;
  createdAt: string;
}

export interface AttendanceEntry {
  employeeId: number;
  employeeCode: string;
  employeeName: string;
  departmentName: string;
  designation: string | null;
  status: string;
  inTime1: string | null;
  outTime1: string | null;
  inTime2: string | null;
  outTime2: string | null;
  hoursWorked: number | null;
  note: string | null;
}

export interface DayAttendance {
  date: string;
  entries: AttendanceEntry[];
  summary: { present: number; absent: number; late: number; halfDay: number; onLeave: number; total: number };
}

export interface Leave {
  id: number;
  employeeId: number;
  employeeCode: string;
  employeeName: string;
  departmentName: string;
  leaveType: string;
  startDate: string;
  endDate: string;
  reason: string | null;
  status: string;
  days: number;
  createdAt: string;
}

export interface OvertimeEntry {
  id: number;
  employeeId: number;
  employeeCode: string;
  employeeName: string;
  departmentName: string;
  date: string;
  hours: number;
  reason: string | null;
  createdAt: string;
}

export interface PayrollEmployee {
  serial: number;
  employeeId: number;
  employeeCode: string;
  employeeName: string;
  departmentName: string;
  monthlyWage: number;
  statsEligible: boolean;
  otEligible: boolean;
  daysPresent: number;
  leaves: number;
  otHours: number;
  basicPayable: number;
  otAmount: number;
  totalPayable: number;
  openingAdvance: number;
  advanceBank: number;
  advanceCash: number;
  hraElec: number;
  pfAmount: number;
  esiAmount: number;
  deductions: number;
  closingAdvance: number;
  balanceCheque: number;
  finalPayable: number;
}

export interface PayrollResponse {
  month: string;
  workingDays: number;
  totals: { basicPayable: number; otAmount: number; totalPayable: number; deductions: number; finalPayable: number };
  employees: PayrollEmployee[];
}

export interface DashboardSummary {
  totalEmployees: number;
  totalDepartments: number;
  todayPresent: number;
  todayAbsent: number;
  todayOnLeave: number;
  todayAttendanceRate: number;
  monthAttendanceRate: number;
  pendingLeaveRequests: number;
  overtimeHoursThisMonth: number;
  recentActivity: unknown[];
}

export interface LeaveBalance {
  employeeId: number;
  CL: { allotted: number; used: number; remaining: number };
  SL: { allotted: number; used: number; remaining: number };
  EL: { allotted: number; used: number; remaining: number };
  LOP: { used: number };
}

// ─── Query Keys ───────────────────────────────────────────────────────────────

export const getListDepartmentsQueryKey = () => ["departments"] as const;
export const getListEmployeesQueryKey = (params?: { departmentId?: number }) => ["employees", params] as const;
export const getDayAttendanceQueryKey = (date: string, departmentId?: number) => ["attendance", "day", date, departmentId] as const;
export const getListLeavesQueryKey = (params?: { status?: string; employeeId?: number }) => ["leaves", params] as const;
export const getLeaveBalanceQueryKey = (employeeId: number) => ["leaves", "balance", employeeId] as const;
export const getListOvertimeQueryKey = (params?: { month?: string; employeeId?: number }) => ["overtime", params] as const;
export const getPayrollQueryKey = (month: string) => ["payroll", month] as const;
export const getDashboardSummaryQueryKey = () => ["dashboard", "summary"] as const;

// ─── Departments ──────────────────────────────────────────────────────────────

export function useListDepartments() {
  return useQuery({
    queryKey: getListDepartmentsQueryKey(),
    queryFn: () => apiFetch<Department[]>("/departments"),
  });
}

export function useCreateDepartment() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: { name: string; code?: string; displayOrder?: number }) =>
      apiFetch<Department>("/departments", { method: "POST", body: JSON.stringify(body) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: getListDepartmentsQueryKey() }),
  });
}

export function useDeleteDepartment() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (departmentId: number) =>
      apiFetch<void>(`/departments/${departmentId}`, { method: "DELETE" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: getListDepartmentsQueryKey() }),
  });
}

// ─── Employees ────────────────────────────────────────────────────────────────

export function useListEmployees(params?: { departmentId?: number }) {
  const search = params?.departmentId ? `?departmentId=${params.departmentId}` : "";
  return useQuery({
    queryKey: getListEmployeesQueryKey(params),
    queryFn: () => apiFetch<Employee[]>(`/employees${search}`),
  });
}

export function useGetEmployee(employeeId: number) {
  return useQuery({
    queryKey: ["employees", employeeId],
    queryFn: () => apiFetch<{ employee: Employee; monthAttendanceRate: number; daysPresentThisMonth: number; daysAbsentThisMonth: number; overtimeHoursThisMonth: number; leaveBalance: LeaveBalance }>(`/employees/${employeeId}`),
    enabled: !!employeeId,
  });
}

export function useCreateEmployee() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: { employeeCode: string; name: string; departmentId: number; designation?: string; monthlyWage?: number; statsEligible?: boolean; otEligible?: boolean }) =>
      apiFetch<Employee>("/employees", { method: "POST", body: JSON.stringify(body) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: getListEmployeesQueryKey() }),
  });
}

export function useUpdateEmployee() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ employeeId, ...body }: { employeeId: number; name?: string; departmentId?: number; designation?: string; monthlyWage?: number; statsEligible?: boolean; otEligible?: boolean }) =>
      apiFetch<Employee>(`/employees/${employeeId}`, { method: "PATCH", body: JSON.stringify(body) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: getListEmployeesQueryKey() }),
  });
}

export function useDeleteEmployee() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (employeeId: number) =>
      apiFetch<void>(`/employees/${employeeId}`, { method: "DELETE" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: getListEmployeesQueryKey() }),
  });
}

// ─── Attendance ───────────────────────────────────────────────────────────────

export function useGetDayAttendance(date: string, departmentId?: number) {
  const search = departmentId ? `?date=${date}&departmentId=${departmentId}` : `?date=${date}`;
  return useQuery({
    queryKey: getDayAttendanceQueryKey(date, departmentId),
    queryFn: () => apiFetch<DayAttendance>(`/attendance/day${search}`),
    enabled: !!date,
  });
}

export function useSetDayAttendance() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: { date: string; entries: Partial<AttendanceEntry>[] }) =>
      apiFetch<DayAttendance>("/attendance/day", { method: "PUT", body: JSON.stringify(body) }),
    onSuccess: (_, vars) => qc.invalidateQueries({ queryKey: getDayAttendanceQueryKey(typeof vars.date === "string" ? vars.date : "") }),
  });
}

// ─── Leaves ───────────────────────────────────────────────────────────────────

export function useListLeaves(params?: { status?: string; employeeId?: number }) {
  const parts = [];
  if (params?.status) parts.push(`status=${params.status}`);
  if (params?.employeeId) parts.push(`employeeId=${params.employeeId}`);
  const search = parts.length ? `?${parts.join("&")}` : "";
  return useQuery({
    queryKey: getListLeavesQueryKey(params),
    queryFn: () => apiFetch<Leave[]>(`/leaves${search}`),
  });
}

export function useGetLeaveBalance(employeeId: number) {
  return useQuery({
    queryKey: getLeaveBalanceQueryKey(employeeId),
    queryFn: () => apiFetch<LeaveBalance>(`/leaves/balance/${employeeId}`),
    enabled: !!employeeId,
  });
}

export function useCreateLeave() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: { employeeId: number; leaveType: string; startDate: string; endDate: string; reason?: string }) =>
      apiFetch<Leave>("/leaves", { method: "POST", body: JSON.stringify(body) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["leaves"] }),
  });
}

export function useUpdateLeaveStatus() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ leaveId, status }: { leaveId: number; status: string }) =>
      apiFetch<Leave>(`/leaves/${leaveId}`, { method: "PATCH", body: JSON.stringify({ status }) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["leaves"] }),
  });
}

export function useDeleteLeave() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (leaveId: number) =>
      apiFetch<void>(`/leaves/${leaveId}`, { method: "DELETE" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["leaves"] }),
  });
}

// ─── Overtime ─────────────────────────────────────────────────────────────────

export function useListOvertime(params?: { month?: string; employeeId?: number }) {
  const parts = [];
  if (params?.month) parts.push(`month=${params.month}`);
  if (params?.employeeId) parts.push(`employeeId=${params.employeeId}`);
  const search = parts.length ? `?${parts.join("&")}` : "";
  return useQuery({
    queryKey: getListOvertimeQueryKey(params),
    queryFn: () => apiFetch<OvertimeEntry[]>(`/overtime${search}`),
  });
}

export function useCreateOvertime() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: { employeeId: number; date: string; hours: number; reason?: string }) =>
      apiFetch<OvertimeEntry>("/overtime", { method: "POST", body: JSON.stringify(body) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["overtime"] }),
  });
}

export function useDeleteOvertime() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (overtimeId: number) =>
      apiFetch<void>(`/overtime/${overtimeId}`, { method: "DELETE" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["overtime"] }),
  });
}

// ─── Payroll ──────────────────────────────────────────────────────────────────

export function useGetPayroll(month: string) {
  return useQuery({
    queryKey: getPayrollQueryKey(month),
    queryFn: () => apiFetch<PayrollResponse>(`/payroll?month=${month}`),
    enabled: !!month,
  });
}

export function useUpdatePayrollLine() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ employeeId, ...body }: { employeeId: number; month: string; openingAdvance?: number; advanceBank?: number; advanceCash?: number; hraElec?: number; closingAdvance?: number; balanceCheque?: number; notes?: string }) =>
      apiFetch(`/payroll/${employeeId}`, { method: "PUT", body: JSON.stringify(body) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["payroll"] }),
  });
}

// ─── Dashboard ────────────────────────────────────────────────────────────────

export function useGetDashboardSummary() {
  return useQuery({
    queryKey: getDashboardSummaryQueryKey(),
    queryFn: () => apiFetch<DashboardSummary>("/dashboard/summary"),
  });
}
