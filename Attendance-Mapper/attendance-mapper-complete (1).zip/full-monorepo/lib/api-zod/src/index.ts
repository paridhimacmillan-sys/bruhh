import { z } from "zod";

// ─── Health ───────────────────────────────────────────────────────────────────
export const HealthCheckResponse = z.object({ status: z.literal("ok") });

// ─── Departments ──────────────────────────────────────────────────────────────
export const CreateDepartmentBody = z.object({
  name: z.string().min(1).max(100),
  code: z.string().max(20).optional(),
  displayOrder: z.number().int().optional(),
});

export const DeleteDepartmentParams = z.object({
  departmentId: z.number().int().positive(),
});

// ─── Employees ────────────────────────────────────────────────────────────────
export const CreateEmployeeBody = z.object({
  employeeCode: z.string().min(1).max(20),
  name: z.string().min(1).max(100),
  departmentId: z.number().int().positive(),
  designation: z.string().max(100).optional(),
  monthlyWage: z.number().min(0).optional(),
  statsEligible: z.boolean().optional(),
  otEligible: z.boolean().optional(),
});

export const UpdateEmployeeBody = z.object({
  employeeCode: z.string().min(1).max(20).optional(),
  name: z.string().min(1).max(100).optional(),
  departmentId: z.number().int().positive().optional(),
  designation: z.string().max(100).optional(),
  monthlyWage: z.number().min(0).optional(),
  statsEligible: z.boolean().optional(),
  otEligible: z.boolean().optional(),
});

export const GetEmployeeParams = z.object({ employeeId: z.number().int().positive() });
export const UpdateEmployeeParams = z.object({ employeeId: z.number().int().positive() });
export const DeleteEmployeeParams = z.object({ employeeId: z.number().int().positive() });
export const ListEmployeesQueryParams = z.object({
  departmentId: z.coerce.number().int().positive().optional(),
});

// ─── Attendance ───────────────────────────────────────────────────────────────
const AttendanceStatus = z.enum(["present", "absent", "late", "half_day", "on_leave"]);

export const GetDayAttendanceQueryParams = z.object({
  date: z.coerce.date(),
  departmentId: z.coerce.number().int().positive().optional(),
});

export const SetDayAttendanceBody = z.object({
  date: z.coerce.date(),
  entries: z.array(
    z.object({
      employeeId: z.number().int().positive(),
      status: AttendanceStatus,
      inTime1: z.string().optional(),
      outTime1: z.string().optional(),
      inTime2: z.string().optional(),
      outTime2: z.string().optional(),
      note: z.string().optional(),
    }),
  ),
});

// ─── Leaves ───────────────────────────────────────────────────────────────────
const LeaveType = z.enum(["CL", "SL", "EL", "LOP"]);
const LeaveStatus = z.enum(["pending", "approved", "rejected"]);

export const CreateLeaveBody = z.object({
  employeeId: z.number().int().positive(),
  leaveType: LeaveType,
  startDate: z.coerce.date(),
  endDate: z.coerce.date(),
  reason: z.string().optional(),
});

export const UpdateLeaveStatusParams = z.object({ leaveId: z.number().int().positive() });
export const UpdateLeaveStatusBody = z.object({ status: LeaveStatus });
export const DeleteLeaveParams = z.object({ leaveId: z.number().int().positive() });
export const GetLeaveBalanceParams = z.object({ employeeId: z.number().int().positive() });
export const ListLeavesQueryParams = z.object({
  status: LeaveStatus.optional(),
  employeeId: z.coerce.number().int().positive().optional(),
});

// ─── Overtime ─────────────────────────────────────────────────────────────────
export const CreateOvertimeBody = z.object({
  employeeId: z.number().int().positive(),
  date: z.coerce.date(),
  hours: z.number().positive().max(24),
  reason: z.string().optional(),
});

export const DeleteOvertimeParams = z.object({ overtimeId: z.number().int().positive() });
export const ListOvertimeQueryParams = z.object({
  month: z.string().regex(/^\d{4}-\d{2}$/).optional(),
  employeeId: z.coerce.number().int().positive().optional(),
});

// ─── Payroll ──────────────────────────────────────────────────────────────────
export const GetPayrollQueryParams = z.object({
  month: z.string().regex(/^\d{4}-\d{2}$/),
});

export const UpdatePayrollLineParams = z.object({ employeeId: z.number().int().positive() });
export const UpdatePayrollLineBody = z.object({
  month: z.string().regex(/^\d{4}-\d{2}$/),
  openingAdvance: z.number().min(0).optional(),
  advanceBank: z.number().min(0).optional(),
  advanceCash: z.number().min(0).optional(),
  hraElec: z.number().min(0).optional(),
  closingAdvance: z.number().min(0).optional(),
  balanceCheque: z.number().min(0).optional(),
  notes: z.string().optional(),
});

// ─── Reports ──────────────────────────────────────────────────────────────────
export const GetDailyReportQueryParams = z.object({ date: z.coerce.date() });
export const GetMonthlyReportQueryParams = z.object({
  month: z.string().regex(/^\d{4}-\d{2}$/),
  departmentId: z.coerce.number().int().positive().optional(),
});
export const GetAbsenteeismReportQueryParams = z.object({
  month: z.string().regex(/^\d{4}-\d{2}$/),
});
export const GetForm12ReportQueryParams = z.object({
  month: z.string().regex(/^\d{4}-\d{2}$/),
});
