export { db } from "./client";
export {
  departmentsTable,
  employeesTable,
  attendanceTable,
  leavesTable,
  overtimeTable,
  payrollLinesTable,
} from "./schema";
