import { pgTable, serial, varchar, integer, boolean, numeric, timestamp, text, unique } from "drizzle-orm/pg-core";

// ─── Departments ──────────────────────────────────────────────────────────────
export const departmentsTable = pgTable("departments", {
  id:           serial("id").primaryKey(),
  name:         varchar("name", { length: 100 }).notNull(),
  code:         varchar("code", { length: 20 }),
  displayOrder: integer("display_order").notNull().default(0),
  createdAt:    timestamp("created_at").notNull().defaultNow(),
});

// ─── Employees ────────────────────────────────────────────────────────────────
export const employeesTable = pgTable("employees", {
  id:            serial("id").primaryKey(),
  employeeCode:  varchar("employee_code", { length: 20 }).notNull().unique(),
  name:          varchar("name", { length: 100 }).notNull(),
  departmentId:  integer("department_id").notNull().references(() => departmentsTable.id, { onDelete: "restrict" }),
  designation:   varchar("designation", { length: 100 }),
  monthlyWage:   numeric("monthly_wage", { precision: 10, scale: 2 }).notNull().default("0"),
  statsEligible: boolean("stats_eligible").notNull().default(true),
  otEligible:    boolean("ot_eligible").notNull().default(true),
  createdAt:     timestamp("created_at").notNull().defaultNow(),
});

// ─── Attendance ───────────────────────────────────────────────────────────────
export const attendanceTable = pgTable(
  "attendance",
  {
    id:          serial("id").primaryKey(),
    employeeId:  integer("employee_id").notNull().references(() => employeesTable.id, { onDelete: "cascade" }),
    date:        varchar("date", { length: 10 }).notNull(), // YYYY-MM-DD
    status:      varchar("status", { length: 20 }).notNull(), // present | absent | late | half_day | on_leave
    inTime1:     varchar("in_time1", { length: 5 }),   // HH:MM
    outTime1:    varchar("out_time1", { length: 5 }),
    inTime2:     varchar("in_time2", { length: 5 }),
    outTime2:    varchar("out_time2", { length: 5 }),
    hoursWorked: numeric("hours_worked", { precision: 5, scale: 2 }),
    note:        text("note"),
    updatedAt:   timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [unique().on(t.employeeId, t.date)],
);

// ─── Leaves ───────────────────────────────────────────────────────────────────
export const leavesTable = pgTable("leaves", {
  id:         serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull().references(() => employeesTable.id, { onDelete: "cascade" }),
  leaveType:  varchar("leave_type", { length: 10 }).notNull(), // CL | SL | EL | LOP
  startDate:  varchar("start_date", { length: 10 }).notNull(), // YYYY-MM-DD
  endDate:    varchar("end_date", { length: 10 }).notNull(),
  reason:     text("reason"),
  status:     varchar("status", { length: 20 }).notNull().default("pending"), // pending | approved | rejected
  createdAt:  timestamp("created_at").notNull().defaultNow(),
});

// ─── Overtime ─────────────────────────────────────────────────────────────────
export const overtimeTable = pgTable("overtime", {
  id:         serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull().references(() => employeesTable.id, { onDelete: "cascade" }),
  date:       varchar("date", { length: 10 }).notNull(), // YYYY-MM-DD
  hours:      numeric("hours", { precision: 5, scale: 2 }).notNull(),
  reason:     text("reason"),
  createdAt:  timestamp("created_at").notNull().defaultNow(),
});

// ─── Payroll Lines ────────────────────────────────────────────────────────────
export const payrollLinesTable = pgTable(
  "payroll_lines",
  {
    id:              serial("id").primaryKey(),
    employeeId:      integer("employee_id").notNull().references(() => employeesTable.id, { onDelete: "cascade" }),
    month:           varchar("month", { length: 7 }).notNull(), // YYYY-MM
    openingAdvance:  numeric("opening_advance", { precision: 10, scale: 2 }).notNull().default("0"),
    advanceBank:     numeric("advance_bank", { precision: 10, scale: 2 }).notNull().default("0"),
    advanceCash:     numeric("advance_cash", { precision: 10, scale: 2 }).notNull().default("0"),
    hraElec:         numeric("hra_elec", { precision: 10, scale: 2 }).notNull().default("0"),
    closingAdvance:  numeric("closing_advance", { precision: 10, scale: 2 }).notNull().default("0"),
    balanceCheque:   numeric("balance_cheque", { precision: 10, scale: 2 }).notNull().default("0"),
    notes:           text("notes"),
    updatedAt:       timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [unique().on(t.employeeId, t.month)],
);
